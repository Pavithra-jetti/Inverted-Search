#include "inv.h"

/* Restore the database from a backup file */
int retrieve_database(main_node *arr[], Slist **head)
{
    char filename[100];

    printf("Enter backup file name: ");
    scanf("%99s", filename);

    /* Validate file extension */
    char *extension = strrchr(filename, '.');

    if (extension == NULL || strcmp(extension, ".txt") != 0)
    {
        printf("Invalid backup file.\n");
        return FAILURE;
    }

    FILE *fptr = fopen(filename, "r");

    if (fptr == NULL)
    {
        printf("Unable to open backup file.\n");
        return FAILURE;
    }

    /* Check whether the backup file is empty */
    if (fgetc(fptr) == EOF)
    {
        fclose(fptr);
        printf("Backup file is empty.\n");
        return FAILURE;
    }

    rewind(fptr);

    /* Store files added during this restore operation */
    Slist *new_files = NULL;
    char line[500];

    while (fgets(line, sizeof(line), fptr) != NULL)
    {
        char *token = strtok(line, "#;");

        if (token == NULL)
        {
            continue;
        }

        int index = atoi(token);

        token = strtok(NULL, "#;");

        if (token == NULL)
        {
            continue;
        }

        char word[100];
        strcpy(word, token);

        token = strtok(NULL, "#;");

        if (token == NULL)
        {
            continue;
        }

        int file_count = atoi(token);

        /* Search for the word in the current database */
        main_node *current = arr[index];
        main_node *previous = NULL;

        while (current != NULL)
        {
            if (strcmp(current->word, word) == 0)
            {
                break;
            }

            previous = current;
            current = current->mainlink;
        }

        /* Restore each file associated with the word */
        for (int i = 0; i < file_count; i++)
        {
            token = strtok(NULL, "#;");

            if (token == NULL)
            {
                break;
            }

            char file[100];
            strcpy(file, token);

            token = strtok(NULL, "#;");

            if (token == NULL)
            {
                break;
            }

            int word_count = atoi(token);

            /* Check whether the file already exists */
            Slist *file_node = *head;
            int file_exists = 0;

            while (file_node != NULL)
            {
                if (strcmp(file_node->file, file) == 0)
                {
                    file_exists = 1;
                    break;
                }

                file_node = file_node->link;
            }

            if (file_exists)
            {
                continue;
            }

            /* Create the main node if the word does not exist */
            if (current == NULL)
            {
                current = malloc(sizeof(main_node));

                if (current == NULL)
                {
                    fclose(fptr);
                    return FAILURE;
                }

                strcpy(current->word, word);
                current->file_count = 0;
                current->sublink = NULL;
                current->mainlink = NULL;

                if (arr[index] == NULL)
                {
                    arr[index] = current;
                }
                else
                {
                    previous->mainlink = current;
                }
            }

            /* Create a sub node for the restored file */
            sub_node *new_sub_node = malloc(sizeof(sub_node));

            if (new_sub_node == NULL)
            {
                fclose(fptr);
                return FAILURE;
            }

            strcpy(new_sub_node->filename, file);
            new_sub_node->word_count = word_count;
            new_sub_node->slink = NULL;

            /* Add the sub node to the end of the list */
            if (current->sublink == NULL)
            {
                current->sublink = new_sub_node;
            }
            else
            {
                sub_node *sub_current = current->sublink;

                while (sub_current->slink != NULL)
                {
                    sub_current = sub_current->slink;
                }

                sub_current->slink = new_sub_node;
            }

            current->file_count++;

            /* Store the newly restored file */
            Slist *new_file = new_files;
            int file_recorded = 0;

            while (new_file != NULL)
            {
                if (strcmp(new_file->file, file) == 0)
                {
                    file_recorded = 1;
                    break;
                }

                new_file = new_file->link;
            }

            if (!file_recorded)
            {
                insert_last(file, &new_files);
            }
        }
    }

    fclose(fptr);

    /* Add restored files to the main file list */
    Slist *new_file = new_files;

    while (new_file != NULL)
    {
        insert_last(new_file->file, head);
        new_file = new_file->link;
    }

    /* Free the temporary file list */
    new_file = new_files;

    while (new_file != NULL)
    {
        Slist *temp = new_file;
        new_file = new_file->link;
        free(temp);
    }

    return SUCCESS;
}