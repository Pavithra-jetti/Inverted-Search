#include "inv.h"

/* Display the inverted search database */
void display_database(Slist *head, main_node *arr[])
{
    (void)head;

    printf("\n%-6s %-15s %-10s %-20s %-10s\n",
           "Index", "Word", "Files", "File Name", "Count");

    printf("-----------------------------------------------------------------\n");

    for (int index = 0; index < 27; index++)
    {
        if (arr[index] == NULL)
        {
            continue;
        }

        main_node *main_current = arr[index];

        while (main_current != NULL)
        {
            sub_node *sub_current = main_current->sublink;
            int first_file = 1;

            while (sub_current != NULL)
            {
                if (first_file)
                {
                    printf("%-6d %-15s %-10d %-20s %-10d\n",
                           index,
                           main_current->word,
                           main_current->file_count,
                           sub_current->filename,
                           sub_current->word_count);

                    first_file = 0;
                }
                else
                {
                    printf("%-6s %-15s %-10s %-20s %-10d\n",
                           "",
                           "",
                           "",
                           sub_current->filename,
                           sub_current->word_count);
                }

                sub_current = sub_current->slink;
            }

            main_current = main_current->mainlink;
        }
    }

    printf("-----------------------------------------------------------------\n");
}