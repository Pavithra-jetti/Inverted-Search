/*
 * Name        : J Pavithra
 * Date        : 09/08/2026
 * Description : Inverted Search project in C that indexes words from
 *               multiple text files using a hash table for efficient searching.
 */

#include "inv.h"

int main(int argc, char *argv[])
{
    main_node *arr[27] = {NULL};
    Slist *head = NULL;
    int choice;

    if (argc < 2)
    {
        printf("Usage: ./a.out <file1> <file2> ...\n");
        return FAILURE;
    }

    /* Validate and store input files */
    for (int i = 1; i < argc; i++)
    {
        if (read_validate(argv[i], head) == SUCCESS)
        {
            insert_last(argv[i], &head);
        }
    }

    print_list(head);

    printf("\n============================================\n");
    printf("       INVERTED SEARCH DATABASE\n");
    printf("============================================\n");

    do
    {
        printf("\n1. Create Database\n");
        printf("2. Search Word\n");
        printf("3. Display Database\n");
        printf("4. Save Database\n");
        printf("5. Update Database\n");
        printf("6. Retrieve Database\n");
        printf("7. Exit\n");

        printf("\nEnter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                if (database_empty(arr) == FAILURE)
                {
                    printf("Database already exists.\n");
                }
                else if (create_database(head, arr) == SUCCESS)
                {
                    printf("Database created successfully.\n");
                }
                else
                {
                    printf("Failed to create database.\n");
                }
                break;

            case 2:
                if (database_empty(arr) == SUCCESS)
                {
                    printf("Database is empty. Create the database first.\n");
                }
                else
                {
                    search_database(arr);
                }
                break;

            case 3:
                if (database_empty(arr) == SUCCESS)
                {
                    printf("Database is empty. Create the database first.\n");
                }
                else
                {
                    display_database(head, arr);
                }
                break;

            case 4:
                if (database_empty(arr) == SUCCESS)
                {
                    printf("Database is empty. Create the database first.\n");
                }
                else if (save_database(arr) == SUCCESS)
                {
                    printf("Database saved successfully.\n");
                }
                else
                {
                    printf("Failed to save database.\n");
                }
                break;

            case 5:
                if (update_database(arr, head) == SUCCESS)
                {
                    printf("Database updated successfully.\n");
                }
                else
                {
                    printf("Failed to update database.\n");
                }
                break;

            case 6:
                if (retrieve_database(arr, &head) == SUCCESS)
                {
                    printf("Database retrieved successfully.\n");
                }
                else
                {
                    printf("Failed to retrieve database.\n");
                }
                break;

            case 7:
                printf("\nThank you for using Inverted Search.\n");
                break;

            default:
                printf("Invalid choice. Please try again.\n");
        }

    } while (choice != 7);

    return SUCCESS;
}

/* Add a filename to the linked list */
int insert_last(char *filename, Slist **head)
{
    Slist *new_node = malloc(sizeof(Slist));

    if (new_node == NULL)
    {
        return FAILURE;
    }

    strcpy(new_node->file, filename);
    new_node->link = NULL;

    if (*head == NULL)
    {
        *head = new_node;
    }
    else
    {
        Slist *temp = *head;

        while (temp->link != NULL)
        {
            temp = temp->link;
        }

        temp->link = new_node;
    }

    return SUCCESS;
}

/* Display registered input files */
void print_list(Slist *head)
{
    printf("\nInput Files:\n");

    if (head == NULL)
    {
        printf("No valid input files found.\n");
        return;
    }

    Slist *temp = head;

    while (temp != NULL)
    {
        printf("- %s\n", temp->file);
        temp = temp->link;
    }
}

/* Check whether the database is empty */
int database_empty(main_node *arr[])
{
    for (int i = 0; i < 27; i++)
    {
        if (arr[i] != NULL)
        {
            return FAILURE;
        }
    }

    return SUCCESS;
}
