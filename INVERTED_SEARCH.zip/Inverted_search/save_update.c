#include "inv.h"

/* Save the inverted search database to a backup file */
int save_database(main_node *arr[])
{
    char filename[100];

    printf("Enter backup file name: ");
    scanf("%99s", filename);

    /* Validate file extension */
    char *extension = strrchr(filename, '.');

    if (extension == NULL || strcmp(extension, ".txt") != 0)
    {
        printf("Invalid file format. Use a .txt file.\n");
        return FAILURE;
    }

    FILE *fptr = fopen(filename, "w");

    if (fptr == NULL)
    {
        printf("Unable to create backup file.\n");
        return FAILURE;
    }

    for (int index = 0; index < 27; index++)
    {
        if (arr[index] == NULL)
        {
            continue;
        }

        main_node *main_current = arr[index];

        while (main_current != NULL)
        {
            fprintf(fptr, "#%d;%s;%d;",
                    index,
                    main_current->word,
                    main_current->file_count);

            sub_node *sub_current = main_current->sublink;

            while (sub_current != NULL)
            {
                fprintf(fptr, "%s;%d;",
                        sub_current->filename,
                        sub_current->word_count);

                sub_current = sub_current->slink;
            }

            fprintf(fptr, "#\n");

            main_current = main_current->mainlink;
        }
    }

    fclose(fptr);

    return SUCCESS;
}


/* Add a new text file to the database */
int update_database(main_node *arr[], Slist *head)
{
    char filename[100];

    printf("Enter new file name: ");
    scanf("%99s", filename);

    /* Validate file extension */
    char *extension = strrchr(filename, '.');

    if (extension == NULL || strcmp(extension, ".txt") != 0)
    {
        printf("Invalid file format. Use a .txt file.\n");
        return FAILURE;
    }

    /* Check whether the file exists */
    FILE *fptr = fopen(filename, "r");

    if (fptr == NULL)
    {
        printf("File not found.\n");
        return FAILURE;
    }

    fclose(fptr);

    /* Add the file to the list */
    if (insert_last(filename, &head) == FAILURE)
    {
        printf("Unable to add the file.\n");
        return FAILURE;
    }

    /* Find the newly added file */
    Slist *current = head;
    Slist *previous = NULL;

    while (current->link != NULL)
    {
        previous = current;
        current = current->link;
    }

    /* Update the database with the new file */
    if (strcmp(filename, current->file) == 0)
    {
        create_database(current, arr);
        return SUCCESS;
    }

    return FAILURE;
}