#include "inv.h"

/* Search for a word in the inverted database */
void search_database(main_node *arr[])
{
    char word[100];

    printf("\nEnter word to search: ");
    scanf("%99s", word);

    int word_found = 0;
    int index = tolower(word[0]) - 'a';

    if (index < 0 || index > 25)
    {
        index = 26;
    }

    main_node *current = arr[index];

    while (current != NULL)
    {
        if (strcmp(current->word, word) == 0)
        {
            printf("\nSearch Result\n");
            printf("-------------\n");
            printf("Word      : %s\n", current->word);
            printf("Files     : %d\n", current->file_count);

            printf("\n%-20s %-10s\n", "File Name", "Count");
            printf("----------------------------------------\n");

            sub_node *sub_current = current->sublink;

            while (sub_current != NULL)
            {
                printf("%-20s %-10d\n",
                       sub_current->filename,
                       sub_current->word_count);

                sub_current = sub_current->slink;
            }

            word_found = 1;
            break;
        }

        current = current->mainlink;
    }

    if (!word_found)
    {
        printf("\nWord \"%s\" was not found.\n", word);
    }
}