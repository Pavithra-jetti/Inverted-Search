#include "inv.h"

/* Validate the input file */
int read_validate(char *file, Slist *head)
{
    char *extension = strrchr(file, '.');

    /* Check file extension */
    if (extension == NULL || strcmp(extension, ".txt") != 0)
    {
        return FAILURE;
    }

    /* Check whether the file exists and is readable */
    FILE *fptr = fopen(file, "r");

    if (fptr == NULL)
    {
        return FAILURE;
    }

    /* Check whether the file is empty */
    if (fgetc(fptr) == EOF)
    {
        fclose(fptr);
        return FAILURE;
    }

    fclose(fptr);

    /* Check for duplicate file names */
    Slist *temp = head;

    while (temp != NULL)
    {
        if (strcmp(temp->file, file) == 0)
        {
            return FAILURE;
        }

        temp = temp->link;
    }

    return SUCCESS;
}


/* Create the inverted search database */
int create_database(Slist *head, main_node *arr[])
{
    char word[100];

    /* Process each input file */
    while (head != NULL)
    {
        FILE *fptr = fopen(head->file, "r");

        if (fptr == NULL)
        {
            return FAILURE;
        }

        /* Read each word from the file */
        while (fscanf(fptr, "%99s", word) != EOF)
        {
            /* Convert the word to lowercase */
            for (int i = 0; word[i] != '\0'; i++)
            {
                word[i] = tolower(word[i]);
            }

            /* Calculate hash index */
            int index = word[0] - 'a';

            /* Use index 26 for special characters */
            if (index < 0 || index > 25)
            {
                index = 26;
            }

            /* Create the first main node */
            if (arr[index] == NULL)
            {
                arr[index] = create_mnode(word, head);
            }
            else
            {
                main_node *current = arr[index];
                main_node *previous = NULL;
                int word_found = 0;

                /* Search for the word */
                while (current != NULL)
                {
                    if (strcmp(current->word, word) == 0)
                    {
                        word_found = 1;

                        sub_node *sub_current = current->sublink;
                        sub_node *sub_previous = NULL;
                        int file_found = 0;

                        /* Search for the file */
                        while (sub_current != NULL)
                        {
                            if (strcmp(head->file,
                                       sub_current->filename) == 0)
                            {
                                sub_current->word_count++;
                                file_found = 1;
                                break;
                            }

                            sub_previous = sub_current;
                            sub_current = sub_current->slink;
                        }

                        /* Add a new sub node for a new file */
                        if (file_found == 0)
                        {
                            sub_node *new_sub_node = create_snode(head);

                            if (new_sub_node == NULL)
                            {
                                fclose(fptr);
                                return FAILURE;
                            }

                            sub_previous->slink = new_sub_node;
                            current->file_count++;
                        }

                        break;
                    }

                    previous = current;
                    current = current->mainlink;
                }

                /* Add a new main node for a new word */
                if (word_found == 0)
                {
                    main_node *new_main_node =
                        create_mnode(word, head);

                    if (new_main_node == NULL)
                    {
                        fclose(fptr);
                        return FAILURE;
                    }

                    previous->mainlink = new_main_node;
                }
            }
        }

        fclose(fptr);

        /* Move to the next input file */
        head = head->link;
    }

    return SUCCESS;
}


/* Create a main node for a new word */
main_node *create_mnode(char word[], Slist *head)
{
    main_node *new_node = malloc(sizeof(main_node));

    if (new_node == NULL)
    {
        return NULL;
    }

    strcpy(new_node->word, word);

    new_node->file_count = 1;
    new_node->sublink = create_snode(head);
    new_node->mainlink = NULL;

    if (new_node->sublink == NULL)
    {
        free(new_node);
        return NULL;
    }

    return new_node;
}


/* Create a sub node for a file */
sub_node *create_snode(Slist *head)
{
    sub_node *new_node = malloc(sizeof(sub_node));

    if (new_node == NULL)
    {
        return NULL;
    }

    strcpy(new_node->filename, head->file);

    new_node->word_count = 1;
    new_node->slink = NULL;

    return new_node;
}