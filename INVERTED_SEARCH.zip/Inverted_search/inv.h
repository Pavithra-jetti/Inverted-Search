#ifndef INV_H
#define INV_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define SUCCESS 0
#define FAILURE -1

/* Main node stores a word and its file information */
typedef struct MainNode
{
    char word[100];
    int file_count;
    struct Subnode *sublink;
    struct MainNode *mainlink;

} main_node;

/* Sub node stores file name and word occurrence count */
typedef struct Subnode
{
    int word_count;
    char filename[100];
    struct Subnode *slink;

} sub_node;

/* Linked list for storing input file names */
typedef struct slist
{
    char file[100];
    struct slist *link;

} Slist;


/* File handling */
int read_validate(char *file, Slist *head);
int insert_last(char *filename, Slist **head);
void print_list(Slist *head);


/* Database creation */
int create_database(Slist *head, main_node *arr[]);
main_node *create_mnode(char word[], Slist *head);
sub_node *create_snode(Slist *head);


/* Database operations */
void display_database(Slist *head, main_node *arr[]);
void search_database(main_node *arr[]);
int save_database(main_node *arr[]);
int update_database(main_node *arr[], Slist *head);
int retrieve_database(main_node *arr[], Slist **head);


/* Utility */
int database_empty(main_node *arr[]);

#endif